'''
Created on Feb 24, 2023

@author: coleo
'''

from WarFiles.GolfPlayer import GolfPlayer as GP
from WarFiles.DeckOfCards import DeckOfCards as DC
import random


class GolfGame(object):    


    def __init__(self):
        '''
        Constructor
        
        Parameters:
            none
        '''
        self.deck = DC()
        self.rounds = 0
        self.winners = [0, 0, 0]
        self.player1 = GP()
        self.player2 = GP()
        self.drawPile = []
        self.discardPile = []
        
        
        
    def playRound(self):
        '''
            plays a round of golf
            
            preconditions:
              none
            postcondition:
              * a round is played and the scores from the round are tallied
        '''
        size = int(input("How many cards should I deal you? (4 is standard): "))
        peeks = int(input("Ok... now how many cards can you see? (2 is standard): "))
        assert(size < 12)
        assert(peeks < 12)
        self.deal(size)#deals size number of cards to each player
        self.player1.visibleCards(peeks)#sets the number of 'seeable' cards
        self.player2.visibleCards(peeks)
        while self.deck.hasNext():
            self.drawPile.append(self.deck.dealCard())
        knock = False#tracks whether a player has knocked (game ends after a player knocks)
        player = random.randint(1,2) #randomly select a player to go first
        print(f"Player {player} goes first!")        
        while knock == False:
            print("****************")
            print("****************")
            print("****************")
            print("****************")
            print("****************")
            print("****************")
            print("****************")
            print("****************")
            print("No Peeking!")
            currPlayer = self.player2#set the current player
            if player == 1:
                currPlayer = self.player1
            print(f"Hello {currPlayer.name}. You can either draw from the draw pile or pick up a {self.discardPile[0]}")
            print(f"Your cards are {currPlayer.seeHand()}")
            whichPile = int(input("Draw pile or take the top discard? (1=draw, 0=discard): "))
            pile = ["draw from the Draw Pile", self.drawPile]#keep track of the pile to draw from
            if(whichPile == 0):
                pile = ["draw from the Discard Pile", self.discardPile]
            print(f"Ok, you have chosen to {pile[0]}, your card is: {pile[1][0]}")
            position = int(input(f"Where would you like to place your card? (0-{size-1}) (-1 to discard)"))
            self.takeTurn(position, whichPile, player)#take a turn
            knock = bool(input("Would you like to knock? (ends the round)? (y/"")"))
            player = 3-player#change players
            self.roundOver()#end the round
        winner = self.whoWon()
        if winner == 0:
            print("Its a tie!")
        else:
            print(f"Player {winner} won!")
        print(f"Player 1: {self.winners[1]} wins. Player 2: {self.winners[2]} wins. {self.winners[0]} ties")
        
        
        
    def takeTurn(self, position, discard: int, playerN):
        '''
            has a player take their turn. called by the playRound function
            parameters:
                position: Int
                discard: Int
                playerN: Int
            preconditions:
              * position is -1, or a valid spot in our hand
              * discard is 0 or 1 depending which pile the user wants to draw from
              * playerN is the int of a valid golf player
            postcondition:
              * a turn is taken with a card replaced in the player's hand or discarded
        '''
        if position == -1:#discard the card we are given (dont place in hand)
            discardCard = self.drawPile[0]
            self.drawPile = self.drawPile[1:]
            self.discardPile.insert(0,discardCard)
        else:
            player = None
            discardCard = None
            if playerN == 1:
                if discard == 0: #take the top card on the discard pile and swap
                    discardCard = self.player1.swapCard(position, self.discardPile[0])
                else: #take the top card on the draw pile and swap
                    discardCard = self.player1.swapCard(position, self.drawPile[0])
                    self.drawPile = self.drawPile[1:]
                self.discardPile.insert(0,discardCard)
            elif playerN == 2:
                if discard == 0: #take the top card on the discard pile and swap
                    discardCard = self.player2.swapCard(position, self.discardPile[0])
                else: #take the top card on the draw pile and swap
                    discardCard = self.player2.swapCard(position, self.drawPile[0])
                    self.drawPile = self.drawPile[1:]
                self.discardPile.insert(0,discardCard)
        
    
        

    
    def setup(self):
        '''
            prints the rules to the screen
            
            preconditions:
               none
            postcondition:
               none
        '''
        print("SETUP FUNCTION")
        print("Welcome to Golf")
        print("Here are the rules of Golf: ")
        print("Players will be dealt an equal number of face down cards each")
        print("The player with the lowest score at the end of each round wins the round")
        print("You can either keep track of your total score or the number of rounds won")
        print("Each round will have at most 9 turns")
        print("When it is your turn you can draw from the draw or the discard pile")
        print("Choose to either replace a card in your hand or discard the card that you draw")
        print("You can peek at your first row of cards")
        print("Your deck positions move from left to right and closest to furthest")
        print("You can see cards in the first row, which is from 0-your row size")
        print("Good luck")
        print("Let's start with the basics: ")
        self.player1.changeName(str(input("What is player 1's name? ")))
        self.player2.changeName(str(input("What is player 2's name? ")))
        print("Let the game begin!")
    
    
    def whoWon(self):
        '''
            checks to see which player had a lower score
            
            preconditions:
              none
            postcondition:
              returns the winner from the round and keeps track of the total winners from a game
        '''
        winner = 2
        sum1 = self.player1.computeScore()#Compute each score
        sum2 = self.player2.computeScore()
        print(f"Final Score: {sum1} - {sum2}")
        if (sum1 > sum2):
            winner = 1
        if(sum1 == sum2): #set the winner to be P1 P2 or tie
            winner = 0
        self.winners[winner] = self.winners[winner]+1 #keep track of wins and ties
        return winner
    
    def playGame(self):
        '''
            assigns cards from the deck to each of the players
            
            preconditions:
              * warDeck is not empty
              * warDeck has enough cards to EVENLY split between the players
            postcondition:
              * each player has half of the cards from the deck in their hand.
        '''
        self.setup()#Setup prints out all the rules
        again = True
        while again: #while the user wants to play again
            self.reset() #reset shuffles the deck and clears the hands
            self.playRound() #play a round
            again = self.askAgain() #want to play again?
       
    def roundOver(self):
        '''
            increments the number of rounds played
            
            preconditions:
               none
            postcondition:
               the number of rounds played increases by 1
        '''
        self.rounds+=1
    
    
    def askAgain(self):
        '''
        ***Borrowed from War class***
            local helper function for validating input
            Returns True if the user selects something yes-like.  Returns False if they select something no-like.
            
            preconditions: None
            postconditions:
              * Returns True if user enters something from the validY list.
              * Returns False if user enters something from the validN list.
        '''
        validY = ["y", "yes", "yeah", "yup", "ok", "yes please"]
        validN = ["n", "no", "nope", "nah", "no thanks", "no thank you"]
        user_in = ""
        while user_in.lower() not in validY + validN:
            user_in = input("Play again? (Y/N)")
        if user_in.lower() in validY:
            return True
        else:
            return False
    
    def reset(self):
        '''
            resets the deck and clears player's hands and the discard pile
            
            preconditions:
              none
            postcondition:
              the deck is reset, each player's hand is cleared and the deck is shuffled 
        '''
        self.deck.reset()
        self.discardPile = []
        self.player1.clearHand()
        self.player2.clearHand()
        self.deck.shuffle()
        
    
        
        
    def deal(self, size):
        '''
            deals cards to each player
            parameters:
                size: Int
            preconditions:
              * size is less than the number of cards we have in our deck / 2
            postcondition:
              * each player has size number of the cards from the deck in their hand.
        '''
        index = 0
        while index < size:
            self.player1.hand.append(self.deck.dealCard())
            self.player2.hand.append(self.deck.dealCard())
            index+=1
        self.discardPile.append(self.deck.dealCard())
    
        
           
        
if __name__  == "__main__":
    golfGame = GolfGame()
    golfGame.playGame()
    