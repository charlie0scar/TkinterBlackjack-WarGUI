'''
Created on Mar 2, 2023

@author: coleo
'''

import tkinter as tk
from tkinter import messagebox
from WarFiles.DeckOfCards import DeckOfCards as DC 
from WarFiles.BlackjackPlayer import BlackjackPlayer

class BlackjackGUI():
    def __init__(self, wn, card_images = "deck4.png"):
        '''
        Constructor
        Parameters:
            window to draw the GUI on, and the images of our deck of cards
        '''
        # Create a deck, a player and a dealer
        self.__bDeck = DC(card_images)
        self.__player1 = BlackjackPlayer()
        self.__dealer = BlackjackPlayer()
        # Set up the canvases
        self.__player1Frame = tk.LabelFrame(wn, text = "Player1", width = 52*3 + DC.width, height = DC.height * 5)
        self.__p1Canvas = tk.Canvas(self.__player1Frame, width = 52*3 + DC.width, height = DC.height * 5)
        self.__dealerFrame = tk.LabelFrame(wn, text = "Dealer", width = 52*3 + DC.width, height = DC.height * 5)
        self.__p2Canvas = tk.Canvas(self.__dealerFrame, width = 52*3 + DC.width, height = DC.height * 5)
        self.__battleGroundFrame = tk.LabelFrame(wn, text = "Controls", width = 30, height = 10)#DC.height * 2.5)
        self.__BGCanvas = tk.Canvas(self.__battleGroundFrame,  width = 30, height = 10)
        self.__player1Frame.grid(row = 0, column = 0)
        self.__dealerFrame.grid(row = 0, column = 2)
        self.__battleGroundFrame.grid(row = 0, column = 1)
        self.__p1Canvas.grid(row = 0, column = 0)
        self.__p2Canvas.grid(row = 0, column = 0)
        self.__BGCanvas.grid(row = 0, column = 0)
        self.__btnFlip = tk.Button(self.__battleGroundFrame, text = "Hit Me", command = self.flip)
        self.__btnFlip.grid(row = 1, column = 0)
        self.__btnFlip = tk.Button(self.__battleGroundFrame, text = "Hold Button", command = self.hold)
        self.__btnFlip.grid(row = 2, column = 0)
        self.__btnNewGame = tk.Button(self.__battleGroundFrame, text = "New Game", command = self.newGame)
        self.__btnNewGame.grid(row = 3, column = 0)
        
        
    def score(self):
        '''
            checks the score of the player's hand and then adds cards to the dealer's hand until they win or bust
            
            Parameters:
                none
            
            preconditions: none
            postcondition: 
              * the winner as a string to be passed to the text box
        '''
        p1Hand = self.__player1.getHand()
        dealHand = self.__dealer.getHand()
        score1 = 0
        scoreA1 = 0
        scoreD = 0
        scoreAD = 0
        for i in range(len(p1Hand)):
            score1+= p1Hand[i].getValue()
            scoreA1+= p1Hand[i].getValue()
            if(p1Hand[i].getValue() == 1):
                scoreA1+= 10
        for i in range(len(dealHand)):
            scoreD+= dealHand[i].getValue()
            scoreAD += dealHand[i].getValue()
            if(dealHand[i].getValue() == 1):
                scoreAD+= 10

        if(self.bust()):
            if score1 < 22:
                return f"{self.__player1.name} Wins"
            return "Dealer Wins"
        if scoreD == 21 or scoreAD == 21:
            return "Dealer Wins"
        if score1 == 21 or scoreA1 == 21:
            return f"{self.__player1.name} Wins"
        if scoreD < 21 and scoreD > score1:
            return "Dealer Wins"
        else:
            while(scoreD <= 21 and scoreD < score1):
                self.__dealer.hit(self.__bDeck.dealCard())
                for i in range(len(dealHand)):
                    scoreD+= dealHand[i].getValue()
                    scoreAD += dealHand[i].getValue()
                self.render()
                if(self.bust()):
                    if score1 < 22:
                        return f"{self.__player1.name} Wins"
                    return "Dealer Wins"
                if scoreD == 21 or scoreAD == 21:
                    return "Dealer Wins"
                if scoreD < 21 and scoreD > score1:
                    return "Dealer Wins"
                if score1 > scoreD:
                    return f"{self.__player1.name} Wins"
                return "Dealer Wins"
        
         
    def bust(self):
        '''
            checks whether either player has busted 
            
            Parameters:
                none
            
            preconditions: none
            postcondition: 
              * boolean yes if a player is over 21
        '''
        p1Hand = self.__player1.getHand()
        dealHand = self.__dealer.getHand()
        score1 = 0
        scoreD = 0
        for i in range(len(p1Hand)):
            score1+= p1Hand[i].getBlackjackValue()
        for i in range(len(dealHand)):
            scoreD+= dealHand[i].getBlackjackValue()
        if score1 > 21 or scoreD > 21:
            return True
        else:
            return False
        
        
        
    def reset(self):
        '''
            resets the GUI
            
            Parameters:
                none
            
            preconditions: none
            postcondition: 
              * none
        '''
        self.__bDeck.shuffle()
        self.__player1 = BlackjackPlayer()
        self.__dealer = BlackjackPlayer()
        self.hold = False
        
    def dealCards(self):
        '''
            deals 2 cards to the player and the dealer
            
            Parameters:
                none
            
            preconditions: none
            postcondition: 
              * none
        '''
        for _ in range(2):
            self.__player1.hit(self.__bDeck.dealCard())
            self.__dealer.hit(self.__bDeck.dealCard()) 

    def newGame(self):
        '''
            starts a new Blackjack game by resetting the GUI, dealing cards and rendering the window
            
            Parameters:
                none
            
            preconditions: none
            postcondition: 
              * none
        '''
        self.reset()
        self.dealCards()
        self.render()

    def render(self):
        '''
            renders the GUI window
            
            Parameters:
                none
            
            preconditions: none
            postcondition: 
              * none
        '''
        self.__p1Canvas.delete(tk.ALL)
        self.__p2Canvas.delete(tk.ALL)
        self.__BGCanvas.delete(tk.ALL)
        hand1 = self.__player1.getHand()
        handD = self.__dealer.getHand()
        for i in range(len(hand1)):
            hand1[i].draw(self.__p1Canvas, top = 10+i*DC.height, left = 10)
        for i in range(len(handD)):
            handD[i].draw(self.__p2Canvas, top = 10+i*DC.height, left = 10)
        #self.__player1.draw(self.__p1Canvas)
        if len(handD) <= 2:
            self.__dealer.draw(self.__p2Canvas)
        
     
    def hold(self):
        '''
            ends the current game 
            
            Parameters:
                none
            
            preconditions: none
            postcondition: 
              * none
        '''
        winner = self.score()
        messagebox.showinfo(title = f"{winner}")    
        answer = messagebox.askyesno(title = "Game Over", message = "Game is over.  Play again?")
        if answer == tk.YES:
            self.reset()
            self.dealCards()
        self.render()
        
        
    def flip(self):
        '''
            "hits" the player then determines whether to end the game or continue based on the player's score
            
            Parameters:
                none
            
            preconditions: none
            postcondition: 
              * none
        '''
        p1C = self.__bDeck.dealCard()
        self.__player1.hit(p1C)
        self.render()
        if self.bust()==True or self.hold == True:
            winner = self.score()
            messagebox.showinfo(title = f"{winner}")    
            answer = messagebox.askyesno(title = "Game Over", message = "Game is over.  Play again?")
            if answer == tk.YES:
                self.reset()
                self.dealCards()
        
            
    
        
if __name__ == "__main__":
    wn = tk.Tk()
    myWar = BlackjackGUI(wn)
    wn.mainloop()
    