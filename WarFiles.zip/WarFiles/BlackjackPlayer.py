'''
NAME
    BlackjackPlayer

DESCRIPTION
    This module provides a class to represent a single player in a game of Blackjack (could also be a dealer).
    
    It also provides unit testing for each of the class methods.

DEPENDENCIES
    Card.py    (implicitly)
    DeckOfCards.py
             
Created by: Cole Odegard
Created on: March 3, 2023
'''

from WarFiles.DeckOfCards import DeckOfCards as DC

class BlackjackPlayer(object):
    '''
    A class used to represent a simple playing card.
    
    Attributes:
        __hand: list<Card>
            a list containing this player's war cards
        name: str
            the name of this player.
    
    Methods:
        hit(c: card): None
            adds specified card to player's hand
        hold(): Card
            returns the 'top' card from this player's hand
        cardsLeft(): int
            returns the number of cards remaining in the player's hand
        hasNext(): bool
            returns True if this player has cards left in their hand
        prepareWar(): list<Card>
            returns a list of (up to) 3 cards from the player's hand
        draw(cvs: Canvas, left: int, top: int): None 
            renders this player's hand to the specified canvas at the given coordinates.
    '''

    def __init__(self, name = "Anonymous"):
        '''
        Constructor
        Parameters: 
            name: str
                the player's chosen username
        '''
        self.__hand = []
        self.name = name      

    def getHand(self):
        '''
            returns the player's hand
            
            Parameters:
                none
            
            preconditions: none
            postcondition: 
              * each card in the player's hand
        '''
        returnHand = []
        for i in range(len(self.__hand)):
            returnHand.append(self.__hand[i])
        return returnHand
        
    def hit(self, c):
        '''
            adds the specified card to the player's hand.
            
            Parameters:
                c: Card
                    the card to be added to the hand.
            
            preconditions: none
            postcondition: 
              * the specified card is added to the end of the player's hand
        '''
        self.__hand.append(c)
    
            
    def cardsLeft(self):
        '''
            returns the number of cards remaining in the player's hand
            
            preconditions: none
            postcondition: returns number of cards in the hand.
        '''
        return len(self.__hand)
    
    def hasNext(self):
        '''
            returns True if the user has cards left in their hand.
        '''
        return self.cardsLeft() > 0

        
    
    def draw(self, cvs, left = 10, top = 10):
        '''
            Draws the player's hand to the specified canvas
            Since the player should not be able to see the card faces, just
            draw the back of a card a bunch of times to suggest a 'stack'
            
            Parameters:
                cvs: tkinter.Canvas
                    the canvas object to which the image should be rendered
                left: int
                    the x coordinate at which to start our drawing (left most point)
                top: int
                    the y coordinate at which to start our drawing (top most point)
            
            preconditions: cvs must be a tkinter.Canvas object and must have already been instantiated
            postconditions: draws a 'stack' of cards at the specified location.
        '''        
        for i in range(self.cardsLeft()):
            DC.backOfCard.draw(cvs, top = top, left = left + 3*i)   # Draw the images atop one another, offset by 3 pixels each time.

# End of class BlackjackPlayer

if __name__ == '__main__':
    print("Testing default constructor... ", end = "")
    p1 = BlackjackPlayer()
    assert p1.name == "Anonymous"
    assert p1.cardsLeft() == 0
    assert not p1.hasNext()
    print("Passed!")
    
    print("Testing 'name' constructor... ", end = "")
    p2 = BlackjackPlayer("Iggy")
    assert p2.name == "Iggy"
    assert p2.cardsLeft() == 0
    assert not p2.hasNext()
    print("Passed!")      
    