'''
NAME
    textWar

DESCRIPTION
    This module implements the card game War.

DEPENDENCIES
    Card.py    (implicitly)
    DeckOfCards.py
    WarPlayer.py
             
Created by: Ted Wendt
Created on: February 1, 2022
Modified by: Ted Wendt
Modified on: February 20, 2022
'''

from activity_4.DeckOfCards import DeckOfCards as DC
from activity_4.WarPlayer import WarPlayer as WP

if __name__ == '__main__':
    
    # Create and shuffle a deck
    warDeck = DC(acesHigh = True)
    warDeck.shuffle()
    
    # Create the two players. 
    player1 = WP(name = "Bob")
    player2 = WP(name = "Doug")
    # Create a place to hold the cards while we're determining who wins.
    spoils = WP(name = "spoil")
    
    # Deal out the cards evenly to the two players
    while warDeck.hasNext():
        player1.addCard(warDeck.dealCard())
        player2.addCard(warDeck.dealCard())
        
    rounds = 0
    # Play until either one player is out of cards or 5000 rounds have passed.
    while player1.hasNext() and player2.hasNext() and rounds < 5000:
        rounds += 1
        
        # Ask each player for a card and add them to the spoils
        c1 = player1.playCard()
        c2 = player2.playCard()
        spoils.addCard(c1)
        spoils.addCard(c2)
        
        if c1 == c2:
            # If the card values match, get 3 cards from each player and bury them.
            p1bury = player1.prepWar()
            p2bury = player2.prepWar()
            bury = p1bury + p2bury
            print(f"WAAAAAR!")
            for c in bury:
                spoils.addCard(c)
        else:
            # If there's a clear winner, get ready to assign them the spoils.
            if c1 < c2:
                winner = player2
                print(f"{player2.name}'s {c2} beats {player1.name}'s {c1}.")
            elif c2 < c1:
                winner = player1
                print(f"{player1.name}'s {c1} beats {player2.name}'s {c2}.")
                
            while spoils.hasNext():
                winner.addCard(spoils.playCard())
                
    # When the game is finished, print the final outcome
    if not player1.hasNext():
        print(f"{player1.name} is out of cards.  {player2.name} wins after {rounds} rounds!")
    elif not player2.hasNext():
        print(f"{player2.name} is out of cards.  {player1.name} wins after {rounds} rounds!")
    else:
        print(f'The war has lasted {rounds} long, hard-fought rounds.  Time for peace.')
    