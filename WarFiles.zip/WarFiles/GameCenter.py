'''
Created on Mar 3, 2023

@author: coleo
'''
from WarFiles.BlackjackGUI import BlackjackGUI
from WarFiles.WarGUI import WarGUI
from WarFiles.GolfGame import GolfGame
import tkinter as tk
'''
Gamecenter is just a main class that can run either war, blackjack, golf or war and blackjack. 
Golf cannot be run at the same time as war or blackjack because it is text based.
'''
if __name__ == '__main__':
    wn = tk.Tk()
    w = None
    g = None
    b = None
    games = int(input("Which game would you like to play? (1=BJ, 2 = Golf, 3 = War, 4 = Multiple Games) "))
    if games == 1:
        b = BlackjackGUI(wn)
        wn.mainloop()
    if games == 2:
        g = GolfGame()
        g.playGame()
    if games == 3:
        w = WarGUI(wn)
        wn.mainloop()
    if games == 4:
        mpFrame = tk.LabelFrame(wn,text = "WAR!",width = 52*300, height = 100)
        mpFrame2 = tk.LabelFrame(wn,text = "Blackjack!",width = 52*300, height = 100)
        myWar = WarGUI(mpFrame)
        b = BlackjackGUI(mpFrame2)
        mpFrame.grid(row = 0, column = 0)
        mpFrame2.grid(row = 0, column = 1)
        wn.mainloop()





    
        
    
    
    