'''
Created on Feb 24, 2023

@author: coleo
'''
from WarFiles.DeckOfCards import DeckOfCards

class GolfPlayer(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        Parameters: 
            None
        '''
        self.hand = []
        self.see = []
        self.name = "New Golfer"
        
    def visibleCards(self,peek):
        '''
            sets the number of cards the player can see in their hand
            
            Parameters:
                peek: int
                    the number of cards that can be seen
            
            preconditions: none
            postcondition: 
              * the player's see is initialized to all cards up to peek in the player's hand
        '''
        assert(len(self.hand)>= peek) #make sure we cannot see more cards than we are dealt
        self.see = self.hand[0:peek]
        
    def getCard(self, card):
        '''
            adds a card to the player's hand
            
            Parameters:
                card: Card
                    the card to be added
            
            preconditions: none
            postcondition: 
              * the card is added to the player's hand
        '''
        self.hand.append(card) #add a card to your hand
        
    def clearHand(self):
        '''
            clears the player's hand
            
            Parameters:
                none
            
            preconditions: none
            postcondition: 
              * the player's hand is reset
        '''
        self.hand = []
        
    def computeScore(self):
        '''
            computes the player's score
            
            Parameters:
                none
            
            preconditions: none
            postcondition: 
              * returns the score of the player's cards
        '''
        score = 0
        while len(self.hand) > 0:
            score += self.hand[0].getGolfValue()
            self.hand = self.hand[1:]
        return score
    
    def swapCard(self, position, newcard):
        '''
            takes a card and a position to place the card and returns the old card in that position
            
            Parameters:
                position: int
                    the position to place the new card in a player's hand
                newcard: Card
                    the card to be added to our hand
            preconditions: newCard is a valid card
            postcondition: 
              * the player's old card is returned
        '''
        oldcard = self.hand[position]
        self.hand[position] = newcard
        if position in range(len(self.see)):
            self.see[position] = newcard
        return oldcard
        
    def seeHand(self):
        '''
            returns the player's hand with "Unknown card" for cards that are facedown
            
            Parameters:
                none
            preconditions: none
            postcondition: 
              * an array of the player's cards that they can see is returned
        '''
        cards = []
        lengthf = len(self.hand)
        seeable = len(self.see)
        for index in range(lengthf):
            if index < seeable:
                cards.append(self.see[index].getGolfValue())
            else:
                cards.append("Unknown Card")
        return cards
    
    def changeName(self, name):
        '''
            changes a player's name
            
            Parameters:
                name: String
                    the player's name
            preconditions: none
            postcondition: 
              * the player's name is changed
        '''
        self.name = name
        
        
if __name__ == "__main__":
    gp1 = GolfPlayer()
    deck = DeckOfCards()
    for i in range(5):
        gp1.getCard(deck.dealCard())
    gp1.visibleCards(5)
    print(gp1.hand)
    print(gp1.seeHand())
    print(gp1.swapCard(0,4))
    print(gp1.hand)